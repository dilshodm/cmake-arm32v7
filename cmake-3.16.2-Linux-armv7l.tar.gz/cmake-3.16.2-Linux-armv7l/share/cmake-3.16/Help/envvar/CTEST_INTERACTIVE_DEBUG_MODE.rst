CTEST_INTERACTIVE_DEBUG_MODE
----------------------------

.. include:: ENV_VAR.txt

Environment variable that will exist and be set to ``1`` when a test executed
by :manual:`ctest(1)` is run in interactive mode.
